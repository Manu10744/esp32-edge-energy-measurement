# Example

To run this example:

* Execute `./auto dev` from the root of the project directory to enter the development environment
* Execute `cd example`
* Execute `make`
* This process will build a binary called example in the current working directory. Execute `./example` to execute the
  example.
* In another shell, execute `curl http://0.0.0.0:8000/metrics`